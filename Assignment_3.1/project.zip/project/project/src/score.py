import argparse
import logging
import os
import pickle

import numpy as np
import pandas as pd
from sklearn.impute import SimpleImputer
from sklearn.metrics import mean_absolute_percentage_error, mean_squared_error


def load_test_data(test_data_dir):
    """
    Load the test data set.

    Args:
        test_data_dir (str): Path to folder containing test data set.

    Returns:
        strat_test_set (pandas.DataFrame): Test dataframe.
    """
    test_data_path = os.path.join(test_data_dir, r"test.csv")
    strat_test_set = pd.read_csv(test_data_path)
    return strat_test_set


def load_models(model_dir):
    """
    Load all model pickle files found in the specified directory.

    Args:
        model_dir (str): Path to folder containing model pickle files.

    Returns:
        dict: A dictionary containing trained models, where the keys are the
              model names and the values are the corresponding trained models.
    """
    models = {}
    for filename in os.listdir(model_dir):
        if filename.endswith(".pkl"):
            with open(os.path.join(model_dir, filename), "rb") as f:
                model_name = os.path.splitext(filename)[0]
                models[model_name] = pickle.load(f)
    return models


def score_models(models, strat_test_set, output_dir):
    """
    Score all models on the given test data and save results to the output directory.

    Args:
        models (dict): A dictionary containing trained models, where the keys are the names of the
                       models and the values are the trained model objects.
        strat_test_set (pandas.DataFrame): A pandas DataFrame containing the test data to score the
                       models on.
        output_dir (str): A string representing the path to the directory where the model scores on
                       the test data will be saved.

    Returns:
        None.

    Notes:
        This function will loop through each model in the `models` dictionary and calculate the
        predicted target variable for the `strat_test_set` DataFrame using the `predict()` method
        of each model. It will then calculate and save the root mean squared error (RMSE) and mean
        absolute error (MAE) for each model's predictions on the test data to a CSV file in the
        specified `output_dir`.
    """

    # Score models and save results to output directory
    for model_name, model in models.items():
        logging.debug(f"{model_name} scores are being calculated.")
        X_test = strat_test_set.copy().drop("median_house_value", axis=1)
        y_test = strat_test_set["median_house_value"].copy()
        X_test_num = X_test.copy().drop("ocean_proximity", axis=1)

        imputer = SimpleImputer(strategy="median")
        imputer.fit(X_test_num)
        X_test_prepared = imputer.transform(X_test_num)
        X_test_prepared = pd.DataFrame(
            X_test_prepared, columns=X_test_num.columns, index=X_test.index
        )
        X_test_prepared["rooms_per_household"] = (
            X_test_prepared["total_rooms"] / X_test_prepared["households"]
        )
        X_test_prepared["bedrooms_per_room"] = (
            X_test_prepared["total_bedrooms"] / X_test_prepared["total_rooms"]
        )
        X_test_prepared["population_per_household"] = (
            X_test_prepared["population"] / X_test_prepared["households"]
        )

        X_test_cat = X_test[["ocean_proximity"]]
        X_test_prepared = X_test_prepared.join(pd.get_dummies(X_test_cat, drop_first=True))
        predictions = model.predict(X_test_prepared)
        mse = mean_squared_error(y_test, predictions)
        rmse = np.sqrt(mse)
        mape = mean_absolute_percentage_error(y_test, predictions)
        logging.info(f"Mean Squared Error: {mse}")
        logging.info(f"Root Mean Squared Error: {rmse}")
        logging.info(f"Mean Absolute Percentage Error: {mape}")
        output_path = os.path.join(output_dir, f"{model_name}_scores.txt")
        with open(output_path, "w") as f:
            f.write(f"{model_name} test scores:\n")
            f.write(f"MSE: {mse:.2f}\n")
            f.write(f"RMSE: {rmse:.2f}\n")
            f.write(f"MAPE: {mape:.2f}\n")


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Score models on test data")
    parser.add_argument(
        "--model_dir",
        type=str,
        default="artifacts/model_pickle_files",
        help="path to directory containing model pickle files",
    )
    parser.add_argument(
        "--test_data_dir",
        type=str,
        default="data/raw",
        help="path to directory containing test data",
    )
    parser.add_argument(
        "--output_dir",
        type=str,
        default="data/prediction_scores/test",
        help="path to output directory",
    )
    parser.add_argument(
        "--log-level",
        default="INFO",
        choices=["DEBUG", "INFO", "WARNING", "ERROR", "CRITICAL"],
        help="Set the log level (default: INFO)",
    )
    parser.add_argument("--log-path", help="Set the path of the log file (default: no log file)")
    parser.add_argument(
        "--no-console-log",
        action="store_true",
        help="Disable writing logs to console (default: logs are written to console)",
    )
    args = parser.parse_args()

    if args.log_path:
        logging.basicConfig(
            filename=args.log_path,
            level=args.log_level,
            format="%(asctime)s - %(levelname)s - %(message)s",
        )

    # Always enable console logging unless specified otherwise
    if not args.no_console_log:
        console_handler = logging.StreamHandler()
        console_handler.setLevel(args.log_level)
        console_formatter = logging.Formatter("%(asctime)s - %(levelname)s - %(message)s")
        console_handler.setFormatter(console_formatter)
        console_logger = logging.getLogger()
        console_logger.addHandler(console_handler)
        console_logger.setLevel(args.log_level)

    # Load test data
    strat_test_set = load_test_data(args.test_data_dir)

    # Load models
    models = load_models(args.model_dir)

    # Score models and save results
    score_models(models, strat_test_set, args.output_dir)
