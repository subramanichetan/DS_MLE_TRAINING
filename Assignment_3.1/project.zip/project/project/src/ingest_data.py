import argparse
import logging
import os
import urllib.request

import numpy as np
import pandas as pd
from sklearn.model_selection import StratifiedShuffleSplit

data_url = (
    "https://raw.githubusercontent.com/ageron/handson-ml/master" + "/datasets/housing/housing.csv"
)  # URL to download dataset


def download_dataset(data_url, output_dir):
    """
    Downloads a dataset from a given URL and saves it to a specified output directory.

    Args:
        data_url (str): The URL source of the dataset in CSV format.
        output_dir (str): The folder path in which you want to save the downloaded data.

    Raises:
        OSError: If the specified output directory cannot be created or if the data cannot be
        downloaded.

    Returns:
        None

    This function creates the output directory if it does not already exist, then downloads the
    dataset from the specified URL and saves it as 'data.csv' in the output directory. If the output
    directory already exists and contains a file named 'data.csv', this function will overwrite the
    existing file.
    """

    # Create output directory if it does not exist
    os.makedirs(output_dir, exist_ok=True)

    # Download dataset from URL and extract to output directory
    raw_path = os.path.join(output_dir, "data.csv")
    urllib.request.urlretrieve(data_url, raw_path)
    logging.info(f"Raw dataset downloaded and saved as {raw_path}")


def load_housing_data(data_path):
    """Load the housing dataset from a CSV file.

    Args:
        data_path (str): The path to the CSV file containing the housing dataset.

    Returns:
        pandas.DataFrame: A pandas DataFrame containing the loaded housing dataset.
    """
    return pd.read_csv(data_path)


def create_train_test_split(output_dir, data_url):
    """Create train and test sets from housing data
    This function loads housing data from the specified URL and creates train and test sets from it.
    It also divides the column "median_income" into categories using pd.cut method and drops the
    "income_cat" column after splitting the data.

    Args:
        output_dir (str): The directory where the train and test sets should be saved.
        data_url (str): The URL where the housing data is located.

    Returns:
        None. The function saves the train and test sets as CSV files in the specified output
        directory.

    Raises:
        FileNotFoundError: If the specified output directory does not exist.
    """
    # Load the raw data
    housing = load_housing_data(data_url)

    # Divide the column income category
    housing["income_cat"] = pd.cut(
        housing["median_income"],
        bins=[0.0, 1.5, 3.0, 4.5, 6.0, np.inf],
        labels=[1, 2, 3, 4, 5],
    )

    logging.debug(f"Raw housing data loaded: {housing}")  # Add debug message

    # Split the data into train and test
    split = StratifiedShuffleSplit(n_splits=1, test_size=0.2, random_state=42)

    for train_index, test_index in split.split(housing, housing["income_cat"]):
        strat_train_set = housing.loc[train_index]
        strat_test_set = housing.loc[test_index]

    # Drop the column income category
    for set_ in (strat_train_set, strat_test_set):
        set_.drop("income_cat", axis=1, inplace=True)
    train_path = os.path.join(output_dir, r"train.csv")
    test_path = os.path.join(output_dir, r"test.csv")
    strat_train_set.to_csv(train_path, index=False)
    logging.info(f"Train set created and saved as {train_path}")
    strat_test_set.to_csv(test_path, index=False)
    logging.info(f"Train set created and saved as {train_path}")


if __name__ == "__main__":
    # Parse command line arguments
    parser = argparse.ArgumentParser(
        description=("Download and create training" + "and test datasets.")
    )
    parser.add_argument("--output", type=str, default="data/raw", help="output folder/file path")
    parser.add_argument(
        "--log-level",
        default="INFO",
        choices=["DEBUG", "INFO", "WARNING", "ERROR", "CRITICAL"],
        help="Set the log level (default: INFO)",
    )
    parser.add_argument("--log-path", help="Set the path of the log file (default: no log file)")
    parser.add_argument(
        "--no-console-log",
        action="store_true",
        help="Disable writing logs to console (default: logs are written to console)",
    )
    args = parser.parse_args()

    if args.log_path:
        logging.basicConfig(
            filename=args.log_path,
            level=args.log_level,
            format="%(asctime)s - %(levelname)s - %(message)s",
        )

    # Always enable console logging unless specified otherwise
    if not args.no_console_log:
        console_handler = logging.StreamHandler()
        console_handler.setLevel(args.log_level)
        console_formatter = logging.Formatter("%(asctime)s - %(levelname)s - %(message)s")
        console_handler.setFormatter(console_formatter)
        console_logger = logging.getLogger()
        console_logger.addHandler(console_handler)
        console_logger.setLevel(args.log_level)

    # Download and extract dataset
    download_dataset(data_url, args.output)

    # Create training and validation split
    create_train_test_split(args.output, data_url)

    # Log final message
    logging.info("Done!")
