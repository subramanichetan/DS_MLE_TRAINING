import os
import unittest

from src.train import train_model


class TestTrain(unittest.TestCase):

    def test_train_model(self):
        data_path = 'data/raw'
        model_path = 'artifacts/model_pickle_files'
        output_score_folder = 'data/prediction_scores/train'

        # Call the train_model function with the specified arguments
        train_model(data_path, model_path, output_score_folder)

        # Check that the model file was created
        self.assertTrue(os.path.isfile(model_path))

        # Check that the output score folder was created
        self.assertTrue(os.path.isdir(output_score_folder))


if __name__ == '__main__':
    unittest.main()
