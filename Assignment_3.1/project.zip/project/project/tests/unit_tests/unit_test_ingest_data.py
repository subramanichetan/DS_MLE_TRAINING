import os
import unittest

import pandas as pd
from src.ingest_data import load_housing_data


class TestIngestData(unittest.TestCase):

    def test_load_data(self):
        # create a temporary test file
        test_file_path = 'test_data.csv'
        test_data = pd.DataFrame({
            'col1': [1, 2, 3],
            'col2': ['a', 'b', 'c']
        })
        test_data.to_csv(test_file_path, index=False)

        # test loading the file
        loaded_data = load_housing_data(test_file_path)
        expected_data = test_data

        # assert that the loaded data matches the expected data
        self.assertTrue(loaded_data.equals(expected_data))

        # delete the test file
        os.remove(test_file_path)


if __name__ == '__main__':
    unittest.main()
