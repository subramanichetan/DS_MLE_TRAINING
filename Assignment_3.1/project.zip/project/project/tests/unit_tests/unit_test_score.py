import os
import shutil
import unittest

from src.score import load_models, load_test_data, score_models


class TestScore(unittest.TestCase):

    @classmethod
    def setUpClass(cls):
        # Create a temporary directory for test data and output
        cls.temp_dir = 'temp'
        os.makedirs(cls.temp_dir, exist_ok=True)

        # Copy test models to temporary directory
        shutil.copytree('artifacts/model_pickle_files', os.path.join(cls.temp_dir,
                                                                     'model_pickle_files'))
        shutil.copytree('data/raw', os.path.join(cls.temp_dir, 'raw'))

    @classmethod
    def tearDownClass(cls):
        # Remove temporary directory and all files
        shutil.rmtree(cls.temp_dir)

    def test_load_models(self):
        models = load_models(os.path.join(self.temp_dir, 'model_pickle_files'))
        self.assertEqual(len(models), 4)
        self.assertIn('Best_Estimator_Grid_Search_CV', models)
        self.assertIn('Decision_Tree_Regressor', models)
        self.assertIn('Linear_Regression_Model', models)
        self.assertIn('Randomized_Search_CV', models)
        self.assertIsNotNone(models['Best_Estimator_Grid_Search_CV'])
        self.assertIsNotNone(models['Decision_Tree_Regressor'])
        self.assertIsNotNone(models['Linear_Regression_Model'])
        self.assertIsNotNone(models['Randomized_Search_CV'])

    def test_score_models(self):
        models = load_models(os.path.join(self.temp_dir, 'model_pickle_files'))

        # Check if score files were generated for each model
        strat_test_set = load_test_data(os.path.join(self.temp_dir, 'raw'))
        score_models(models, strat_test_set, self.temp_dir)

        for model_name in models.keys():
            score_file_path = os.path.join(self.temp_dir,
                                           f'{model_name}_scores.txt')
            self.assertTrue(os.path.isfile(score_file_path))

            # Check if scores are valid
        with open(score_file_path, 'r') as f:
            lines = f.readlines()
            self.assertGreater(len(lines), 0)
            self.assertIn(model_name, lines[0])
            self.assertIn('MSE:', lines[1])
            self.assertIn('RMSE:', lines[2])
            self.assertIn('MAPE:', lines[3])


if __name__ == '__main__':
    unittest.main()
